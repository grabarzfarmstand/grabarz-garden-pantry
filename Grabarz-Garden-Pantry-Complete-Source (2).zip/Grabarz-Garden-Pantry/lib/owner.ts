import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { settings } from "@/db/schema";
import { getChatGPTUser } from "@/app/chatgpt-auth";

export async function requireOwnerApi() {
  const user = await getChatGPTUser();
  if (!user) throw new Error("UNAUTHENTICATED");
  const db = getDb();
  const current = await db.select().from(settings).where(eq(settings.id, "owner_user_id")).limit(1);
  if (!current.length) await db.insert(settings).values({ id: "owner_user_id", value: user.userId }).onConflictDoNothing();
  const owner = await db.select().from(settings).where(eq(settings.id, "owner_user_id")).limit(1);
  if (!owner.length || owner[0].value !== user.userId) throw new Error("FORBIDDEN");
  return user;
}
