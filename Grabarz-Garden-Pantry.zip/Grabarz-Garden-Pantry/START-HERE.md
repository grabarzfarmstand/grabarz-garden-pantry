# Grabarz Garden & Pantry — original website source

Exported November 5, 2026, without modifying or publishing the website.
Source commit: a228ff8b2d246e796b42a31ca440b0c416f31324

## What is included

This ZIP preserves every tracked source file in the current website repository, plus this guide. It includes the Grabarz and Rustic Kettle branding, eight bundled image assets, original colors, CSS, responsive layouts, homepage, owner dashboard, product-management API code, database schema and migration, dependency lockfile, and build configuration.

Key files:
- app/page.tsx: storefront layout, copy, category cards and product rendering.
- app/globals.css: custom colors, fonts, spacing and responsive styling.
- app/layout.tsx: shared page structure and metadata.
- public/assets/: original bundled logos and imagery.
- app/owner/: owner dashboard.
- app/api/: product management and image-serving endpoints.
- db/ and drizzle/: database structure and migration.
- package.json and pnpm-lock.yaml: dependencies and scripts.

## Important limits of this backup

This is complete repository source, not a database or hosting-account backup. Live product records and photos uploaded through the owner dashboard reside in hosted D1/R2 storage and are NOT included. Credentials, installed dependencies, build output, Git history and runtime secrets are not included. This export does not establish how much hosted storage has been used.

The website is a React/TypeScript application using Vinext, Cloudflare Workers, D1 database storage and R2 photo storage. It is not a standalone HTML document. Opening its source files does not run the store. A single index.html could preserve a static display but not the existing database, uploads or owner authentication.

The current storefront explicitly says checkout is not active and has disabled ordering buttons. Exporting the source does not add payment processing, working checkout or automatic order-based inventory tracking.

## Using this on another host

The layout, CSS and bundled images can be reused. A developer must configure a compatible build/runtime and database/photo storage, export and migrate any live data separately, and replace or securely integrate the ChatGPT-specific owner sign-in. Do not trust user-supplied identity headers on a replacement host. The .openai/hosting.json file identifies the original Site; do not deploy changes back to it unintentionally.

Node.js >=22.13.0 is declared in package.json. The exact package manager version and dependencies are recorded there and in pnpm-lock.yaml. README.md describes the original development workflow. Dependencies must be installed before building. Environment, storage bindings and authentication must be configured before calling this a working migrated store.

This export was checked for archive integrity and inclusion of tracked files; it has not been independently built or tested on another host. Keep a downloaded copy somewhere you control.
